# Oaxacan Smoky Three-Chile Salsa

## ingredients  
* 5 chiles moritas  
* 5 chiles arbol  
* 5 chiles pasilla  
* 3/4 lbs tomatillos  
* 3 cloves garlic  

## steps
1. Lightly toast the chiles in a cast iron pan until aromatic  
2. Place chiles in a bowl of hot water, cover, and set aside until chiles have softened  
3. Remove stems but leaves seeds, drain and reserve soaking liquid  
4. In a cast iron skillet, toast the tomatillos until black spots form and the garlic until soft  
5. Put garlic, tomatillos, and pinch of salt in blender and blend until smooth  
6. Add chiles and blend, adding soaking water until salsa reaches the desired consistency  

## notes  
* Very hot but really smoky – great with some salty cheese and a shot of mezcal  
* Original recipe also included roasted agave worms :)  

## based on  
* http://cookingwithabroad.com/2013/01/a-3-chile-salsa-with-oaxacan-smokiness/

