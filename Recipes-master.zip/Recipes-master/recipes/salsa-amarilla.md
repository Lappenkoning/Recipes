# Salsa Amarilla  

## ingredients  
* 1 tsp peanut or olive oil  
* 1 medium-sized yellow tomato, cut into quarters  
* 2 long yellow wax chiles (or serrano), stems removed and cut into thirds  
* 1 large clove of garlic, cut into quarters  
* 1 tsp sesame seeds  
* 1/4 cup cilantro, minced  
* pinch of cumin  
* salt to taste  

## steps
1. in a skillet, heat the oil on medium  
2. cook the tomato, chiles, and garlic, turning once, for five minutes or until black spots begin to appear  
3. add sesame seeds and cook for two minutes more  
4. place contents of skillet in blender and puree  
5. stir in cilantro, cumin, and salt  

## based on  
* https://www.seriouseats.com/recipes/2009/08/serious-salsa-salsa-amarilla-recipe.html  

