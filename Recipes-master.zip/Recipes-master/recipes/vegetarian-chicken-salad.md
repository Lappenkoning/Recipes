# Vegetarian Chicken Salad  

## info  
* 10 minutes  
* About 4 servings   

## ingredients  
* 1 cup canned chickpeas (drained, rinsed, and lightly mashed)  
* 8 oz seitan, finely chopped  
* 1 cup diced celery (about 2 stalks)  
* 1/4 cup chopped scallions (about 2)  
* 1 clove garlic, minced  
* 1/3 cup fresh dill, chopped  
* 1/4 cup mayo (or more, if you want creamier salad)  
* 2 tbsp red wine vinegar (or lemon juice?)  
* salt and pepper to taste  

optional additions:  
* 1/2 cup cashews, roughly chopped  
* diced jalepenos or pickled hot peppers  
* curry powder  

## steps
1. Put chickpeas in a bowl and roughly mash with a potato masher  
2. Add other ingredients and stir until fully mixed  
3. Add salt and freshly-ground black pepper to taste  
4. Chill or serve immediately  

## notes  
* Best with some diced red onion and lettuce on rye bread!    
* Keeps in fridge for about 4 days  

## based on  
* https://www.connoisseurusveg.com/seitan-chickpea-salad-with-dill-and-almonds  

