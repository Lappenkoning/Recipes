# Harissa Hot Sauce  

## ingredients  
* 8 dried guagillo chiles (about 2 oz)  
* 8 dried New Mexico chiles (about 1.5 oz)  
* 1/2 tsp caraway seeds  
* 1/4 tsp coriander seeds  
* 1/4 tsp cumin seeds  
* 1 tsp dried mint leaves  
* 3 tbsp olive oil  
* 1.5 tsp kosher salt  
* 5 cloves garlic  
* Juice of 1 lemon  

## steps
1. Put chiles in a bowl, cover with boiling water, and let sit for about 20 minutes  
2. Heat caraway, coriander, and cumin in a skillet, dry toasting until fragrant, about 4 minutes; remove and grind    
3. Drain chiles, remove seeds and add to a food processor with the ground spices, olive oil, salt, garlic, and lemon juice  
4. Puree until very smooth, about 2 minutes  

## notes  
* Can be stored in the fridge for several weeks

## based on  
* https://www.saveur.com/article/Recipes/Harissa  

