# Masala Green Beans  
**(Masala Barbatti Sabji)**

## ingredients
* 3-4 tbsp oil or ghee  
* 2 tsp black mustard seeds  
* 1 tsp cumin seeds  
* 1-2 dried chillies, crushed  
* 1 lb long beans, trimmed and cut into 3/4" pieces (see note)  
* 1 tsp ground coriander  
* 1 tsp salt  
* 1 tsp sugar 

## steps
1. heat oil in pan over medium  
2. when hot, add mustard and cumin seeds, cook until fragrant and mustard seeds begin to pop  
3. add beans, stir to coat in oil  
4. add the remaining ingredients, stir fry for 4-5 minutes or until beans are just beginning to become tender  

## notes  
* Green beans can be substituted for long beans. Fry beans for 2-3 minutes, then add 1/2 cup water, cover and cook until tender. Then add spices and cook until water evaporates.

## based on:
* *Spiced Green Beans* from *The Art of Indian Vegetarian Cooking* by Yamuna Devi  