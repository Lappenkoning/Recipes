# Milagu Sadam  
(Indian Black Pepper Rice)

## info  
* About 45 minutes  
* Enough for 4 servings with a meal    

## ingredients
* 1 cup basmati rice  
* 1 small onion, finely chopped  
* 2.5 tbsp whole black peppercorns, freshly ground  
* 2 sprig curry leaves  
* 1 tsp mustard seeds  
* 1.5 tsp urad dal  
* 10 cashew nuts, whole  

## steps  
1. Wash the rice and let soak for 30–60 minutes  
2. In a large pot, add the rice and water, then cook until the rice is done, about 10 minutes once the water comes to a boil  
3. Drain the rice in a mesh strainer and allow to cool  
4. Wipe the pot dry and add 2 tsp oil, heat and add mustard seeds, cooking until they start to crackle  
5. Add the dal and saute for about 1 minute  
6. Add onions and curry leaves, cooking until onions turn translucent  
7. Add cashews and black pepper, mix and cook for another 1–2 minutes  
8. Add the rice and gently toss to coat with onion-pepper mix, adding salt as necessary  
9. Take off heat, optionally add a pad of butter on top (mixing it in thoroughly when ready to serve)  

## based on  
* https://www.archanaskitchen.com/milagu-sadam-recipe-instant-pepper-rice  

