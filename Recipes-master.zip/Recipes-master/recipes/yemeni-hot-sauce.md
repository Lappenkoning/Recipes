# Zhug
(Yemeni hot sauce)  

## ingredients  
* 1/4 tsp whole coriander seed  
* 1/2 tsp whole cumin seed  
* 1/4 tsp ground black pepper  
* 3 green cardamom pods (optional)  
* 4 medium cloves garlic  
* 4–6 Thai bird chilies (red or green) or 4 dried chiles de árbol (stemmed, seeded, and torn into fine pieces)  
* 1 tsp kosher salt  
* 1 cup parsley, chopped  
* 1 cup cilantro, chopped  
* 1/2 cup olive oil  

## steps
1. Combine coriander seed, cumin, black pepper, and cardamom seeds in a food processor and grind into a powder  
2. Add garlic, chilies, and salt and process until finely chopped  
3. Add cilantro and parsley and continue processing  
4. While the motor is running, slowly pour in olive oil to form an emulsion  
5. Season to taste with more salt  

## notes  
* Can be stored in the fridge for several weeks

## based on  
* https://www.seriouseats.com/recipes/2016/03/schug-zhug-srug-yemenite-israeli-hot-sauce-recipe.html

