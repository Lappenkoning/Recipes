# Beef Tacos  

## info  
* About 15 minutes  
* 2 servings  

## ingredients
* 1 lbs ground beef  
* 1 tsp ground cumin  
* 1 tsp smoked paprika  
* 1/2 tsp garlic powder  
* 1/2 tsp chili powder  
* 1/2 tsp salt  
* 1/2 tsp black pepper  
* 1 tbsp water  

## steps  
1. Heat oil in a cast iron skillet over medium heat, add the beef and cook until it starts to brown  
2. Add seasonings, stir, and cook until done  
3. Add 1 tbsp water to make the beef a bit saucier, stir to combine  

## based on  
* https://www.howsweeteats.com/2019/01/ground-beef-tacos  

