# Teriyaki Chicken  

## info  
* About 40 minutes  
* 2 servings  

## ingredients
* 3/4 lb boneless chicken thighs  
* 4 tbsp soy sauce  
* 4 tbsp mirin  
* 2 tbsp sake  
* 2 tbsp sugar  
* 1 pinch fresh ginger (grated)  
* 1–2 tsp olive oil  

## steps  
1. Remove skin from chicken, if present  
2. Poke chicken with fork to help absorb sauce  
3. Mix sauce ingredients in a large bowl; add chicken and let sit for 15 minutes in the fridge  
4. In a large skillet, heat oil over medium-high heat  
5. Place chicken and skillet, cooking until browned  
6. Flip, reduce heat to low and pour in sauce  
7. Cover and let steam to cook chicken on low heat until done  
8. Remove lid and simmer until sauce thickens slightly; remove pan from heat  
9. Slice chicken and serve, pouring sauce on chicken  

## based on  
* https://www.thespruceeats.com/teriyaki-chicken-2031568  

