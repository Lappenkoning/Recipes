# PIRI-PIRI HOT SAUCE
(An attempt to re-create the hot sauce at The Pit in Bloomfield, New Jersey)

## info  
* About 10 minutes  

## ingredients
* 3 tbsp butter  
* 3 tbsp cilantro, chopped
* 2 garlic cloves, minced
* 2 hot sauce (see note)
* 2 tbsp lemon juice

## steps  
1. Melt butter in a small saucepan over medium-high  
2. Add cilantro and garlic, cooking until garlic starts to brown
3. Add remaining ingredients, reduce to medium-low and simmer about 2 minutes
4. Serve warm on top of BBQ chicken!

## notes  
* While you can (often) buy Portuguese piri-piri sauce in the store, any hot sauce will work ok here – I use sambal olek or even sriracha

## based on  
* https://www.epicurious.com/recipes/food/views/piri-piri-chicken-359750

