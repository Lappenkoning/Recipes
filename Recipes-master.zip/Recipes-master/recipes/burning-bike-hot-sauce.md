# Burning Bike Hot Sauce  
(With carrot and habaneros)

## info  
* 10 minutes  
* 1 mason jar's worth  

## ingredients  
* 1 large carrot, peeled  
* 2 cloves garlic  
* 1/4 yellow onion  
* Juice of 1/2 lime  
* 1.5 tsp white vinegar  
* 1–2 habanero peppers (or 2–4 serranos)  
* 1/8 tsp salt (or more to taste)  

## steps
1. Put veggies in food processor and chop  
2. Add other ingredients and mix until smooth  
3. If too dry, add more vinegar or lime  
4. Add more peppers if you want it more spicy!  
5. Adjust salt to taste  

## notes  
* Recipe from a bike repair camp at Burning Man, posted by Julia Buntaine Hoel  
* Keeps in fridge for... dunno, a while probably

## based on  
* https://www.instagram.com/p/B7G3GpRl9FA  

